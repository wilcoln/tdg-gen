package element.actif;

public enum AttaquantType {
    OBSTACLE,
    MOBILE
}
