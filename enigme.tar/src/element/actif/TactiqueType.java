package element.actif;

public enum TactiqueType {
	attaquePlusFaible,
	attaquePlusFort,
	attaquePlusProche
}
