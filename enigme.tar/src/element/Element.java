package element;

public interface Element {

}
