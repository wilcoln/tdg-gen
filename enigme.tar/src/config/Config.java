package config;

public class Config {
    public static final int PRIX_REPARATION = 1;
    public static final int PRIX_DEPLACEMENT = 1;
    public static int CHECK_TOUR_INTERVAL = 200;
    public static int REFRESH_AFFICHAGE_INTERVAL = 120; // interval entre une évolution du jeu
    public static int STEP_INTERVAL = 800;
}
