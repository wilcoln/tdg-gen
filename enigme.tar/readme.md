# pour tester l'exemple il faut faire: 

