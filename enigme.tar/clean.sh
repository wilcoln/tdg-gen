for i in `find -name *.class`
do
    rm $i
done
