./clean.sh
cd src/
javac *.java */*.java
java ExempleSujet
